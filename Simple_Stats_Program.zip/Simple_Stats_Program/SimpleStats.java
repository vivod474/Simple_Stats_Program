public class SimpleStats {

    // Method 1: Returns average of positive numbers
    public static double averagePositive(int[] nums) {
        if (nums == null || nums.length == 0)
            throw new IllegalArgumentException("Array cannot be null or empty");

        int sum = 0;
        int count = 0;

        for (int num : nums) {
            if (num > 0) {
                sum += num;
                count++;
            }
        }

        if (count == 0) return 0.0;
        return (double) sum / count;
    }

    // Method 2: Counts number of negative numbers
    public static int countNegatives(int[] nums) {
        if (nums == null)
            throw new IllegalArgumentException("Array cannot be null");

        int count = 0;

        for (int num : nums) {
            if (num < 0)
                count++;
        }

        return count;
    }

    // Method 3: Checks if array contains any zero
    public static boolean containsZero(int[] nums) {
        if (nums == null)
            return false;

        for (int num : nums) {
            if (num == 0)
                return true;
        }

        return false;
    }
}
