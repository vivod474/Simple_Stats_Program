public class SimpleStatsTest {

    public static void main(String[] args) {
        testAveragePositive();
        testCountNegatives();
        testContainsZero();
    }

    public static void testAveragePositive() {
        int[] nums = {1, -2, 3, 4};
        double expected = (1 + 3 + 4) / 3.0;
        assert averagePositive(nums) == expected : "Failed testAveragePositive";

        try {
            averagePositive(null);
            assert false : "Expected exception for null input";
        } catch (IllegalArgumentException e) {
            // passed
        }
    }

    public static void testCountNegatives() {
        int[] nums = {-1, -2, 0, 3};
        int expected = 2;
        assert countNegatives(nums) == expected : "Failed testCountNegatives";
    }

    public static void testContainsZero() {
        int[] nums = {1, 0, 3};
        assert containsZero(nums) == true : "Failed testContainsZero";

        int[] nums2 = {1, 2, 3};
        assert containsZero(nums2) == false : "Failed testContainsZero";
    }

    // Bring the methods into scope
    private static double averagePositive(int[] nums) {
        return SimpleStats.averagePositive(nums);
    }

    private static int countNegatives(int[] nums) {
        return SimpleStats.countNegatives(nums);
    }

    private static boolean containsZero(int[] nums) {
        return SimpleStats.containsZero(nums);
    }
}
