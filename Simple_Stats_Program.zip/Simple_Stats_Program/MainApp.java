import java.util.Arrays;

public class MainApp {
    public static void main(String[] args) {
        int[] numbers = {3, -1, 0, 7, -5, 2};

        System.out.println("Input Array: " + Arrays.toString(numbers));

        try {
            double avg = SimpleStats.averagePositive(numbers);
            System.out.println("Average of Positive Numbers: " + avg);
        } catch (IllegalArgumentException e) {
            System.out.println("Error computing average: " + e.getMessage());
        }

        try {
            int negatives = SimpleStats.countNegatives(numbers);
            System.out.println("Count of Negative Numbers: " + negatives);
        } catch (IllegalArgumentException e) {
            System.out.println("Error counting negatives: " + e.getMessage());
        }

        boolean hasZero = SimpleStats.containsZero(numbers);
        System.out.println("Array Contains Zero: " + hasZero);
    }
}
